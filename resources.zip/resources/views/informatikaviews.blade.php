<html>
<body>
<h1>Hello {{$nama}}</h1>
<h1>Ini adalah tampilan yang dibuat menggunakan tampilan blade
</body>
</html>